+{
   locale_version => 0.93,
   entry => <<'ENTRY', # for DUCET v6.2.0
0149      ; [.174F.0020.0009.0149] # LATIN SMALL LETTER N PRECEDED BY APOSTROPHE
ENTRY
};
